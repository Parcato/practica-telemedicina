const express = require('express');
const app = express();
const datos = require('../app_REST_RPC/datos'); // Asegúrate de que el archivo datos.js no tenga errores

app.use(express.json());
app.use('/practica', express.static(__dirname + '/cliente'));
// --- API GESTORES ---

app.post('/api/gestores/login', (req, res) => {
    const { login, password } = req.body;
    const gestor = datos.gestores.find(g => g.usuario === login && g.password === password);
    if (gestor) res.status(200).json(gestor.id);
    else res.status(401).send("Credenciales incorrectas");
});

app.post('/api/gestores/registro', (req, res) => {
    const nuevoGestor = {
        id: datos.gestores.length + 1,
        usuario: req.body.usuario,
        password: req.body.password,
        nombre: req.body.nombre,
        apellidos: req.body.apellidos
    };
    datos.gestores.push(nuevoGestor);
    res.status(201).json(nuevoGestor.id);
});

app.get('/api/gestores/:id', (req, res) => {
    const g = datos.gestores.find(u => u.id == req.params.id);
    if (g) {
        const { password, ...seguro } = g;
        res.json(seguro);
    } else res.status(404).send();
});

// --- API RECURSOS (FILTROS) ---

app.get('/api/recursos', (req, res) => {
    let filtrados = datos.recursos;
    const { categoria, modelo, ubicacion, estado } = req.query;

    if (categoria && categoria !== 'Todos') {
        filtrados = filtrados.filter(r => {
            const m = datos.modelos.find(mod => mod.id == r.modelo);
            return m && m.categoria == categoria;
        });
    }
    if (modelo && modelo !== 'Todos') filtrados = filtrados.filter(r => r.modelo == modelo);
    if (ubicacion && ubicacion !== 'Todos') filtrados = filtrados.filter(r => r.ubicacion == ubicacion);
    if (estado && estado !== 'Todos') filtrados = filtrados.filter(r => r.estado == estado);

    res.json(filtrados);
});
app.get('/api/recursos/:id/reservas', (req, res) => {
    const reservas = datos.reservas.filter(r => r.recursoId == req.params.id);
    res.json(reservas);
});

app.get('/api/recursos/:id/resenyas', (req, res) => {
    const resenyas = datos.resenas.filter(r => r.recursoId == req.params.id);
    res.json(resenyas);
});

app.get('/api/recursos/:id', (req, res) => {
    const r = datos.recursos.find(item => item.id == req.params.id);
    r ? res.json(r) : res.status(404).send();
});

app.post('/api/recursos', (req, res) => {
    const nuevo = { id: Date.now(), ...req.body };
    datos.recursos.push(nuevo);
    res.status(201).json(nuevo);
});

app.put('/api/recursos/:id', (req, res) => {
    const idx = datos.recursos.findIndex(r => r.id == req.params.id);
    if (idx !== -1) {
        datos.recursos[idx] = { ...datos.recursos[idx], ...req.body };
        res.json(datos.recursos[idx]);
    } else res.status(404).send();
});

app.delete('/api/recursos/:id', (req, res) => {
    datos.recursos = datos.recursos.filter(r => r.id != req.params.id);
    res.status(204).send();
});

// Rutas auxiliares
app.get('/api/categorias', (req, res) => res.json(datos.categorias));
app.get('/api/modelos', (req, res) => res.json(datos.modelos));
app.get('/api/ubicaciones', (req, res) => res.json(datos.ubicaciones));

app.listen(3000, () => console.log("Servidor iniciado en http://localhost:3000/practica"));