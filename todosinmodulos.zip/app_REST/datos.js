module.exports = {
    gestores: [
        { id: 1, usuario: "admin", password: "123", nombre: "José", apellidos: "López Ruiz" }
    ],
    categorias: [
        { id: 1, nombre: "Termómetro" },
        { id: 2, nombre: "Pulsioxímetro" }
    ],
    modelos: [
        { id: 101, categoria: 1, nombre: "ASY-234" },
        { id: 102, categoria: 2, nombre: "PX-50" }
    ],
    ubicaciones: [
        { id: 1, nombre: "Almacén 1" },
        { id: 2, nombre: "Planta 3" }
    ],
    recursos: [
        { id: 1, numero_serie: "AD58754", modelo: 101, ubicacion: 1, estado: 0 }
    ],
    reservas: [
    { id: 1, recursoId: 1, sanitario: 1, h_estim: 2, f_peticion: "12/04/25 14:30:50", f_inicio: "12/04/25 14:40:00", f_fin: "12/04/25 16:00:00", estado: 2 }
],
resenas: [
    { id: 1, recursoId: 1, fecha: "11/04/25 13:52:00", sanitario: 1, valoracion: 5, comentario: "Todo perfecto" }
]
};