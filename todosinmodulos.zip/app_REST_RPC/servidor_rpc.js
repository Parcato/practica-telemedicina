var rpc = require("./rpc.js"); 
var datos = require("./datos.js"); 

// --- FUNCIONES DE APOYO CON BUCLES ---

function usuarioExiste(usuario, idAExcluir) {
    for (var i = 0; i < datos.sanitarios.length; i++) {
        if (datos.sanitarios[i].usuario === usuario && datos.sanitarios[i].id !== idAExcluir) {
            return true;
        }
    }
    return false;
}

// --- IMPLEMENTACIÓN DE FUNCIONES ---

function obtenerCategorias(callback) {
    return callback(datos.categorias);
}

function obtenerModelos(callback) {
    return callback(datos.modelos);
}

function loginSanitario(usuario, password, callback) {
    for (var i = 0; i < datos.sanitarios.length; i++) {
        if (datos.sanitarios[i].usuario === usuario && datos.sanitarios[i].password === password) {
            return callback(datos.sanitarios[i].id);
        }
    }
    return callback(null);
}

function crearSanitario(datosSanitario, callback) {
    if (usuarioExiste(datosSanitario.usuario, null)) {
        return callback(null);
    }
    var nuevoId = datos.sanitarios.length + 1;
    datosSanitario.id = nuevoId;
    datos.sanitarios.push(datosSanitario);
    return callback(nuevoId);
}

function actualizarSanitario(idSanitario, datosSanitario, callback) {
    if (usuarioExiste(datosSanitario.usuario, idSanitario)) {
        return callback(null);
    }
    for (var i = 0; i < datos.sanitarios.length; i++) {
        if (datos.sanitarios[i].id == idSanitario) {
            // Actualizamos los campos manteniendo el ID
            datos.sanitarios[i].usuario = datosSanitario.usuario;
            datos.sanitarios[i].nombre = datosSanitario.nombre;
            // ... añadir otros campos necesarios
            return callback(true);
        }
    }
    return callback(false);
}
function retirarRecurso(idReserva, callback) {
    for (var i = 0; i < datos.reservas.length; i++) {
        if (datos.reservas[i].id == idReserva) {
            datos.reservas[i].estado = 2; // En uso

            // SI NO tiene fecha de inicio (porque no le diste a iniciar antes), se la ponemos
           datos.reservas[i].f_inicio = datos.reservas[i].f_peticion;

            // SIEMPRE actualizamos la fecha de "acción" actual en f_fin o una nueva propiedad
datos.reservas[i].f_fin = new Date(new Date(datos.reservas[i].f_peticion).getTime() + (datos.reservas[i].h_estim * 3600000));
            // Actualizar estado del recurso físico
            var idRec = datos.reservas[i].recursoId;
            for (var j = 0; j < datos.recursos.length; j++) {
                if (datos.recursos[j].id == idRec) {
                    datos.recursos[j].estado = 1;
                    break;
                }
            }
            return callback(true);
        }
    }
    return callback(false);
}

function obtenerSanitario(idSanitario, callback) {
    for (var i = 0; i < datos.sanitarios.length; i++) {
        if (datos.sanitarios[i].id == idSanitario) {
            // Creamos una copia para borrar el password antes de enviarlo
            var copia = {};
            for (var key in datos.sanitarios[i]) {
                if (key !== "password") {
                    copia[key] = datos.sanitarios[i][key];
                }
            }
            return callback(copia);
        }
    }
    return callback(null);
}

function obtenerRecurso(idRecurso, callback) {
    for (var i = 0; i < datos.recursos.length; i++) {
        if (datos.recursos[i].id == idRecurso) {
            return callback(datos.recursos[i]);
        }
    }
    return callback(null);
}

function obtenerRecursos(idModelo, callback) {
    var resultados = [];
    for (var i = 0; i < datos.recursos.length; i++) {
        if (datos.recursos[i].modelo == idModelo) {  // quita el && estado == 0 temporalmente para probar
            resultados.push(datos.recursos[i]);
        }
    }
    return callback(resultados);
}

function tiempoPendiente(idRecurso, callback) {
    var totalHoras = 0;
    for (var i = 0; i < datos.reservas.length; i++) {
        // Si el recurso está en una reserva que no ha terminado (estado != 3)
        if (datos.reservas[i].recursoId == idRecurso && datos.reservas[i].estado !== 3) {
            totalHoras += datos.reservas[i].h_estim;
        }
    }
    return callback(totalHoras);
}

function obtenerReservas(idSanitario, callback) {
    var misReservas = [];
    for (var i = 0; i < datos.reservas.length; i++) {
        if (datos.reservas[i].sanitario == idSanitario) {
            misReservas.push(datos.reservas[i]);
        }
    }
    return callback(misReservas);
}

function obtenerResenyas(idRecurso, callback) {
    var lista = [];
    for (var i = 0; i < datos.resenas.length; i++) {
        if (datos.resenas[i].recursoId == idRecurso) {
            lista.push(datos.resenas[i]);
        }
    }
    return callback(lista);
}
function marcarurgente(idReserva, callback) {
    for (var i = 0; i < datos.reservas.length; i++) {
        if (datos.reservas[i].id == idReserva) {
            datos.reservas[i].urgente = true;
            return callback(true);
        }
    }
    return callback(false);
}

function crearResenya(idRecurso, idSanitario, valoracion, descripcion, callback) {
    var id = datos.resenas.length + 1;
    var nueva = {
        id: id,
        recursoId: idRecurso,
        sanitario: idSanitario,
        valoracion: valoracion,
        comentario: descripcion,
        fecha: new Date()
    };
    datos.resenas.push(nueva);
    return callback(id);
}

function reservarRecurso(idRecurso, idSanitario, horasEstimadas, callback) {
    var idRes = datos.reservas.length + 1;
    var nuevaReserva = {
        id: idRes,
        recursoId: idRecurso,
        sanitario: idSanitario,
        h_estim: horasEstimadas,
        f_peticion: new Date(),
        estado: 1 // Reservado
    };
    datos.reservas.push(nuevaReserva);
    return callback(idRes);
}

function cancelarReserva(idReserva, callback) {
    for (var i = 0; i < datos.reservas.length; i++) {
        if (datos.reservas[i].id == idReserva) {
            datos.reservas.splice(i, 1);
            return callback(true);
        }
    }
    return callback(false);
}

function iniciarReserva(idReserva, callback) {
    for (var i = 0; i < datos.reservas.length; i++) {
        if (datos.reservas[i].id == idReserva) {
            datos.reservas[i].estado = 2; // En uso
            datos.reservas[i].f_inicio = new Date();
            return callback(true);
        }
    }
    return callback(false);
}

function finalizarReserva(idReserva, callback) {
    for (var i = 0; i < datos.reservas.length; i++) {
        if (datos.reservas[i].id == idReserva) {
            datos.reservas[i].estado = 3; // Finalizado
            datos.reservas[i].f_fin = new Date();
            return callback(true);
        }
    }
    return callback(false);
}

// --- REGISTRO ---

var servidor = rpc.server();
var app = servidor.createApp("gestion_recursos");

app.registerAsync(obtenerCategorias);
app.registerAsync(obtenerModelos);
app.registerAsync(loginSanitario);
app.registerAsync(crearSanitario);
app.registerAsync(actualizarSanitario);
app.registerAsync(obtenerSanitario);
app.registerAsync(obtenerRecurso);
app.registerAsync(obtenerRecursos);
app.registerAsync(tiempoPendiente);
app.registerAsync(obtenerReservas);
app.registerAsync(obtenerResenyas);
app.registerAsync(crearResenya);
app.registerAsync(reservarRecurso);
app.registerAsync(cancelarReserva);
app.registerAsync(iniciarReserva);
app.registerAsync(finalizarReserva);
app.registerAsync(retirarRecurso);
app.registerAsync(marcarurgente);