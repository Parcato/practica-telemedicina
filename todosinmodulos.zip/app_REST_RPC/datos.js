module.exports = {
    gestores: [
        { id: 1, usuario: "admin", password: "123", nombre: "José", apellidos: "López Ruiz" }
    ],
    sanitarios: [
        { id: 1, usuario: "mestrella2", password: "456", nombre: "María Estrella", apellidos: "López Martínez" },
        { id: 2, usuario: "mestrella", password: "456", nombre: "Luis Navarro", apellidos: "García Martínez" },
        { id: 3, usuario: "estrella", password: "456", nombre: "Juan Perez", apellidos: "López Martínez" }
    ],
    categorias: [
        { id: 1, nombre: "Termómetro" },
        { id: 2, nombre: "Pulsioxímetro" }
    ],
    modelos: [
        { id: 101, categoria: 1, nombre: "ASY-234" },
        { id: 102, categoria: 2, nombre: "PX-50" },
        { id: 103, categoria: 1, nombre: "ASY-234" },
        { id: 104, categoria: 2, nombre: "PX-50" },
        { id: 105, categoria: 1, nombre: "ASY-234" }
    ],
    ubicaciones: [
        { id: 1, nombre: "Almacén 1" },
        { id: 2, nombre: "Planta 3" }
    ],
    recursos: [
        { id: 1, numero_serie: "AD58754", modelo: 101, ubicacion: 1, estado: 0 },
        { id: 2, numero_serie: "AD58754", modelo: 103, ubicacion: 1, estado: 0 },
        { id: 3, numero_serie: "AD58754", modelo: 104, ubicacion: 1, estado: 0 },
        { id: 4, numero_serie: "AD58754", modelo: 102, ubicacion: 1, estado: 0 }
    ],
    reservas: [
        { id: 1, recursoId: 1, sanitario: 1, h_estim: 2, f_peticion: "12/04/25 14:30:50", f_inicio: "12/04/25 14:40:00", f_fin: "12/04/25 16:00:00", estado: 2, urgente: false },
        { id: 2, recursoId: 1, sanitario: 2, h_estim: 2, f_peticion: "12/04/25 14:30:50", f_inicio: "12/04/25 14:40:00", f_fin: "12/04/25 16:00:00", estado: 2, urgente: true},
        { id: 3, recursoId: 1, sanitario: 3, h_estim: 2, f_peticion: "12/04/25 14:30:50", f_inicio: "12/04/25 14:40:00", f_fin: "12/04/25 16:00:00", estado: 1, urgente: false }
    ],
    resenas: [
        { id: 1, recursoId: 1, fecha: "11/04/25 13:52:00", sanitario: "María Estrella López", valoracion: 5, comentario: "Todo perfecto" }
    ]
};